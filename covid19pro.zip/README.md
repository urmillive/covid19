# Covid19 Awareness
My Final Year Collage Project about Covid-19(Corona)
Live Data Fetch using Open API
Show Live Corona Cases and Aware peoples

# Thanks You

https://api.covid19india.org

https://pomber.github.io/covid19/timeseries.json


For More my Website https://urmil8989.online/

## screenshots

![Covid-19 Awareness](Screenshots/01.png/?raw=true "Optional Title")

![Covid-19 Awareness](Screenshots/02.png/?raw=true "Optional Title")

![Covid-19 Awareness](Screenshots/03.png/?raw=true "Optional Title")

![Covid-19 Awareness](Screenshots/04.png/?raw=true "Optional Title")

![Covid-19 Awareness](Screenshots/05.png/?raw=true "Optional Title")

![Covid-19 Awareness](Screenshots/06.png/?raw=true "Optional Title")

![Covid-19 Awareness](Screenshots/07.png/?raw=true "Optional Title")

![Covid-19 Awareness](Screenshots/08.png/?raw=true "Optional Title")

![Covid-19 Awareness](Screenshots/09.png/?raw=true "Optional Title")

![Covid-19 Awareness](Screenshots/10.png/?raw=true "Optional Title")



For More my Website https://urmil8989.online/

Github : https://github.com/urmil89

Instagram : Coder Urmil
